var express = require('express');
var router = express.Router();
var db = require('../db');
/* 도서목록. */
router.get('/list', function (req, res, next) {
    var sql = 'select *, format(price,0) fprice from tbl_book order by code desc';
    db.get().query(sql, function (err, rows) {
        res.send(rows);
    })
});

module.exports = router;
